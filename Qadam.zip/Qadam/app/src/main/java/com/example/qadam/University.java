package com.example.qadam;

import java.io.Serializable;

public class University implements Serializable {
   private String name;
   private int image;
   private double minGrade;
   private String Discription;

    public University(String name, int image, double minGrade, String discription) {
        this.name = name;
        this.image = image;
        this.minGrade = minGrade;
        Discription = discription;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public double getMinGrade() {
        return minGrade;
    }

    public void setMinGrade(double minGrade) {
        this.minGrade = minGrade;
    }

    public String getDiscription() {
        return Discription;
    }

    public void setDiscription(String discription) {
        Discription = discription;
    }
}
