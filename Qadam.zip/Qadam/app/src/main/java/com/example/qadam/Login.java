package com.example.qadam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final EditText name = findViewById(R.id.Name);
        final EditText password = findViewById(R.id.Password);
        Button start = findViewById(R.id.Start);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Name = name.getText().toString();
                String Pass = password.getText().toString();
                Intent intent = new Intent(Login.this, RecyclerView.class);
                intent.putExtra("Password", Pass);
                intent.putExtra("Name", Name);
                startActivity(intent);
            }
        });
    }
}