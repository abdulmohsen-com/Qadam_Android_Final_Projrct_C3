package com.example.qadam;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UniDapter extends RecyclerView.Adapter {
    ArrayList<University> Un;
    Context context;

    public UniDapter(ArrayList<University> un, Context context) {
        Un = un;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vh = LayoutInflater.from(context).inflate(R.layout.university_list_layout,parent, false);
        ViewHolder VH = new ViewHolder(vh);
        return VH;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        ((ViewHolder) holder).image.setImageResource(Un.get(position).getImage());
        ((ViewHolder) holder).name.setText(Un.get(position).getName() + "");
        ((ViewHolder) holder).min.setText(Un.get(position).getMinGrade() + "");
        ((ViewHolder) holder).view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Qadam.class);
                intent.putExtra("University", Un.get(position));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return Un.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder{
        View view;
        ImageView image;
        TextView name;
        TextView min;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            image = itemView.findViewById(R.id.imageView);
            name = itemView.findViewById(R.id.name);
            min = itemView.findViewById(R.id.number);
        }
    }



}
