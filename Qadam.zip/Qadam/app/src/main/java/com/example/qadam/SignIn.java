package com.example.qadam;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SignIn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        final EditText Name = findViewById(R.id.Name);
        final EditText P1 = findViewById(R.id.Password);
        final EditText P2 = findViewById(R.id.Password2);
        final Button Start = findViewById(R.id.Start);
        Start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n = P1.getText().toString();
                String p = P2.getText().toString();
                int p1 = Integer.parseInt(n);
                int p2 = Integer.parseInt(p);
                String name = Name.getText().toString();
                if (p1 == p2){
                    Intent intent = new Intent(SignIn.this , RecyclerView.class);
                    intent.putExtra("Name", name);
                    startActivity(intent);
                }else{
                    AlertDialog.Builder myAlertBuilder = new AlertDialog.Builder(SignIn.this);
                    myAlertBuilder.setTitle("Warning");
                    myAlertBuilder.setMessage("Your Passwords Aren't The Same Please Rewrite Them.");
                    myAlertBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        P1.setText(null);
                        P2.setText(null);
                        }
                    });
                    myAlertBuilder.show();
                }
            }
        });
    }
}