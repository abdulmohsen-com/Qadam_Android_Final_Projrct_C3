package com.example.qadam;
public class RightJustifyAlertDialog{
}
