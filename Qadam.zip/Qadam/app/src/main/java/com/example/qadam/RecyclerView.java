package com.example.qadam;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class RecyclerView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);
        //__________________________________________________-
        TextView name = findViewById(R.id.Name);
        Bundle Airport = getIntent().getExtras();
        //_______________________________________________________
        University KU = new University("جامعة الكويت", R.drawable.kuwait_university_logo, 0.0, "The university aims to preserve and transmit knowledge through scholarship, and encourage innovation and development in the arts and the sciences. It comprises 17 colleges offering 76 undergraduate, 71 graduate programs.");
        University AUM = new University("AUM", R.drawable.aum_logo, 3.0, "American University of the Middle East (AUM) is a private university in Kuwait, founded in 2008. AUM is based in Egaila (Eqaila) in Kuwait, with a campus area of 161,190 square meters and 9000+ students in the year 2017. The American University of the Middle East (AUM) is affiliated with Purdue University in Indiana, US, and is accredited by the Private Universities Council (PUC) of the Government of Kuwait.");
        University GUST = new University("GUST", R.drawable.gust_logo, 2.2, "The university was to be a supplement to Kuwait University, the only institution of higher education in Kuwait at that time, and to serve the educational demands of the local society and the Persian Gulf region. In January 1997, Kuwaiti Academic Group, composed of 41 faculty members from Kuwait University, was founded to lay the foundation for the proposed “University of the Future.” Their studies culminated in a vision of the “Gulf University for Science & Technology.”");
        University AU = new University("الجامعة العربية المفتوحة", R.drawable.arab_uni, 1.0, "");
        University AUK = new University("الجامعة الأمريكية الكويتية", R.drawable.auk_logo, 3.2, "");
        ArrayList<University> UniList = new ArrayList<>();
        UniList.add(KU);
        UniList.add(AUM);
        UniList.add(GUST);
        UniList.add(AU);
        UniList.add(AUK);

        androidx.recyclerview.widget.RecyclerView RV = findViewById(R.id.recycle);
        RV.setHasFixedSize(true);
        androidx.recyclerview.widget.RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        RV.setLayoutManager(lm);
        RV.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        UniDapter UN = new  UniDapter(UniList, this);
        RV.setAdapter(UN);
    }
}