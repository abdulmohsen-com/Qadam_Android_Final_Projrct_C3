package com.example.qadam;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Qadam extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qadam);
        Bundle Qad = getIntent().getExtras();
        final String Name = Qad.getString("Name");
        ImageView image = findViewById(R.id.imageView4);
        TextView non = findViewById(R.id.non);
        TextView name = findViewById(R.id.Name);
        TextView extra = findViewById(R.id.extra);
        TextView min = findViewById(R.id.min);
        Button Back = findViewById(R.id.Back);
        Button apply = findViewById(R.id.Apply);
        non.setText(Name);
        final Bundle Airport = getIntent().getExtras();
        University p = (University) Airport.getSerializable("University");
        image.setImageResource(p.getImage());
        name.setText(p.getName());
        extra.setText("Min Grade To Apply: ");
        min.setText(p.getMinGrade() + "");
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Qadam.this, RecyclerView.class);
                startActivity(intent);
            }
        });
        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder myAlertBuilder = new AlertDialog.Builder(Qadam.this);
                myAlertBuilder.setTitle("تحذير");
                myAlertBuilder.setMessage("إذا لم يكن هناك رد فلا تقبل الجامعة الطالب الآن.");
                myAlertBuilder.setPositiveButton("حسنا", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(Qadam.this, Apply.class);
                    intent.putExtra("Uni", Name);
                    startActivity(intent);
                    }
                });
                myAlertBuilder.show();
            }
        });
    }
}